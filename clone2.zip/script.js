/*변수에 navbar_toogleBtn , 
navbar_menu , navbar_icons 를 각각연결.*/

const toggleBtn = document.querySelector('.navbar_toogleBtn')
const menu = document.querySelector('.navbar_menu')
const icons = document.querySelector('.navbar_icons')

//toggleBtn 이 클릭 될때마다 함수를 호출.

toggleBtn.addEventListener('click', () => {
    menu.classList.toggle('active');
    icons.classList.toggle('active');
});